Tutorial UI iFood Android

Branch start: Projeto inicial
Branch main: Projeto final
